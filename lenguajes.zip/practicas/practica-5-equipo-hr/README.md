# Lenguajes de Programación

## Práctica 5: Evaluación Perezosa

**Fecha de entrega:** 16 de octubre de 2019
