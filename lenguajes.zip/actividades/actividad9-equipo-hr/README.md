# Lenguajes de Programación

## Actividad de Laboratorio 9

**Fecha de entrega:** 9 de octubre de 2019

| Intérprete  | Alcance  | Régimen de evaluación | Resultado expresión |
| :---------: | :------: | :-------------------: | :-----------------: |
| **interp1** | Dinámico | Glotón                | -52                 |        
| **interp2** | Estático | Glotón                | -55                 |        
| **interp3** | Dinámico | Perezoso              | Se cicla            |        
| **interp4** | Estático | Perezoso              | -55                 |        