# Lenguajes de Programación

## Actividad de Laboratorio 8

**Fecha de entrega:** 25 de septiembre de 2019

| Intérprete     | Alcance  | Régimen de evaluación | Implementación |
| :------------: | :------: | :-------------------: | :------------: |
| **interp 1**   | estático | glotón                | sustitición    |
| **interp 2**   | dinámico | glotón                | ambientes      |
| **interp 3**   | estático | glotón                | ambientes con cerraduras |
