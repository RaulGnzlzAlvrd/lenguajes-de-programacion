# Lenguajes de Programación, 2020-1
## Actividad de Laboratorio 1: Introducción a Git

**Nombre del alumno:** González Alvarado Raúl 

**Lenguaje de Programación Favorito:** JavaScript
