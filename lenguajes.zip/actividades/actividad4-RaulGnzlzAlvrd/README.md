# Lenguajes de Programación

## Actividad de Laboratorio 4

**Fecha de entrega:** 28 de agosto de 2019

### Descripción.

Definir un tipo de dato Funcion con los siguientes constructores:

* (cte n) tal que n es un entero.
* (x) tal que x representa una variable.
* (sum f g) tal que f y g son funciones.
* (mul f g) tal que f y g son funciones.
* (pow f n) tal que f es una funcion y n es un exponente.

Definir las funciones:

* (evalua f v) que regresa el resultado de evaluar f(v).
* (deriva f v) que regresa el resultado de evaluar f'(v).